-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2017 at 01:34 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rohinimundra`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignmentone`
--

CREATE TABLE `assignmentone` (
  `id` int(50) NOT NULL,
  `login` varchar(100) NOT NULL,
  `activities_one` varchar(500) NOT NULL,
  `relationships_one` varchar(500) NOT NULL,
  `identity_one` varchar(500) NOT NULL,
  `activities_two` varchar(500) NOT NULL,
  `relationships_two` varchar(500) NOT NULL,
  `identity_two` varchar(500) NOT NULL,
  `activities_three` varchar(500) NOT NULL,
  `relationships_three` varchar(500) NOT NULL,
  `identity_three` varchar(500) NOT NULL,
  `activities_four` varchar(500) NOT NULL,
  `relationships_four` varchar(500) NOT NULL,
  `identity_four` varchar(500) NOT NULL,
  `activities_five` varchar(500) NOT NULL,
  `relationships_five` varchar(500) NOT NULL,
  `identity_five` varchar(500) NOT NULL,
  `activities_six` varchar(500) NOT NULL,
  `relationships_six` varchar(500) NOT NULL,
  `identity_six` varchar(500) NOT NULL,
  `certainty_one` varchar(500) NOT NULL,
  `certainty_two` varchar(500) NOT NULL,
  `variety_one` varchar(500) NOT NULL,
  `variety_two` varchar(500) NOT NULL,
  `significance_one` varchar(500) NOT NULL,
  `significance_two` varchar(500) NOT NULL,
  `connection_one` varchar(500) NOT NULL,
  `connection_two` varchar(500) NOT NULL,
  `growth_one` varchar(500) NOT NULL,
  `growth_two` varchar(500) NOT NULL,
  `contribution_one` varchar(500) NOT NULL,
  `contribution_two` varchar(500) NOT NULL,
  `completed` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignmentone`
--

INSERT INTO `assignmentone` (`id`, `login`, `activities_one`, `relationships_one`, `identity_one`, `activities_two`, `relationships_two`, `identity_two`, `activities_three`, `relationships_three`, `identity_three`, `activities_four`, `relationships_four`, `identity_four`, `activities_five`, `relationships_five`, `identity_five`, `activities_six`, `relationships_six`, `identity_six`, `certainty_one`, `certainty_two`, `variety_one`, `variety_two`, `significance_one`, `significance_two`, `connection_one`, `connection_two`, `growth_one`, `growth_two`, `contribution_one`, `contribution_two`, `completed`) VALUES
(1, 'rohinimundra@rohinimundra.com', '1 q', 'w 2', 'e3', 'r4', 't5', 'y6', 'u7', 'i8', 'o9', 'j0', 'jq', 'hw', 'fre', 'dt', 'ft', 'gy', 'cu', 'gi', 'v1', '3j', '4h', '6g', 'yd', '6s', '7a', '8c', '9h', '0j', '-i', '9u', 0),
(2, 'rajujorhat46@gmail.com', 'yuyh 2122122', ' yugyg', 'ygyg', 'ygy', 'yyug', 'ygy', 'guyg', 'yguy', 'gyugv', 'gvytv', 'ytvyt', 'vyg', 'yguy', 'gyug', 'uguy', 'gyuf', 'ytgyu', 'gyug', 'yhu', 'gyug', 'yg', 'guy', 'gyug', 'yug', 'ug', 'guyg', 'uyg', 'ygui', 'guyg', 'uygyug', 1),
(3, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0),
(4, 'rajujorhat46@gmail.com', ' ', ' ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `assignmenttwo`
--

CREATE TABLE `assignmenttwo` (
  `id` int(50) NOT NULL,
  `login` varchar(500) NOT NULL,
  `answer_one` varchar(1000) NOT NULL,
  `answer_two` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignmenttwo`
--

INSERT INTO `assignmenttwo` (`id`, `login`, `answer_one`, `answer_two`) VALUES
(1, 'rajujorhat46@gmail.com', 'testing1', 'testing2');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_three_day_five`
--

CREATE TABLE `assignment_three_day_five` (
  `s_no` int(50) NOT NULL,
  `login` varchar(100) NOT NULL,
  `situation` varchar(500) NOT NULL,
  `cause` varchar(500) NOT NULL,
  `elp_changed` varchar(500) NOT NULL,
  `outcomes` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_three_day_five`
--

INSERT INTO `assignment_three_day_five` (`s_no`, `login`, `situation`, `cause`, `elp_changed`, `outcomes`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4'),
(2, 'raju12@gmail.com', 'AbCdE', 'EDE', 'E', 'F');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_three_day_four`
--

CREATE TABLE `assignment_three_day_four` (
  `s_no` int(50) NOT NULL,
  `login` varchar(100) NOT NULL,
  `situation` varchar(500) NOT NULL,
  `cause` varchar(500) NOT NULL,
  `elp_changed` varchar(500) NOT NULL,
  `outcomes` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_three_day_four`
--

INSERT INTO `assignment_three_day_four` (`s_no`, `login`, `situation`, `cause`, `elp_changed`, `outcomes`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4'),
(2, 'raju12@gmail.com', 'ppp', 'oo', 'pp', 'oo'),
(3, 'raju12@gmail.com', 'ppp', 'oo', '12122', 'oo'),
(4, 'raju12@gmail.com', 'AbCdE', 'EDE', 'E', 'F123'),
(5, 'raju12@gmail.com', 'AbCdE44', 'EDE44', 'E344', 'F123');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_three_day_one`
--

CREATE TABLE `assignment_three_day_one` (
  `s_no` int(100) NOT NULL,
  `login` varchar(100) NOT NULL,
  `situation` varchar(500) NOT NULL,
  `cause` varchar(500) NOT NULL,
  `elp_changed` varchar(500) NOT NULL,
  `outcomes` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_three_day_one`
--

INSERT INTO `assignment_three_day_one` (`s_no`, `login`, `situation`, `cause`, `elp_changed`, `outcomes`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4'),
(2, 'raju12@gmail.com', '12', '4545', '5454', '56465'),
(3, 'raju12@gmail.com', '77', '77', '767', '676'),
(4, 'raju12@gmail.com', '77', '65465yhy6j', '767', '676'),
(5, 'raju12@gmail.com', 'malli', 'mallu', 'MILLI', 'MALA');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_three_day_seven`
--

CREATE TABLE `assignment_three_day_seven` (
  `s_no` int(50) NOT NULL,
  `login` varchar(100) NOT NULL,
  `situation` varchar(500) NOT NULL,
  `cause` varchar(500) NOT NULL,
  `elp_changed` varchar(500) NOT NULL,
  `outcomes` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_three_day_seven`
--

INSERT INTO `assignment_three_day_seven` (`s_no`, `login`, `situation`, `cause`, `elp_changed`, `outcomes`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4'),
(2, 'raju12@gmail.com', 'uhuihu', 'uhuihui', 'uhuyg', 'tftdrr'),
(3, 'raju12@gmail.com', 'uhuihu555', 'uhuihui55', 'uhuyg', 'tftdrr');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_three_day_six`
--

CREATE TABLE `assignment_three_day_six` (
  `s_no` int(50) NOT NULL,
  `login` varchar(100) NOT NULL,
  `situation` varchar(500) NOT NULL,
  `cause` varchar(500) NOT NULL,
  `elp_changed` varchar(500) NOT NULL,
  `outcomes` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_three_day_six`
--

INSERT INTO `assignment_three_day_six` (`s_no`, `login`, `situation`, `cause`, `elp_changed`, `outcomes`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4'),
(2, 'raju12@gmail.com', '7878', '878', 'QWWQD', 'QEQ'),
(3, 'raju12@gmail.com', 'QE', '878EW', 'QWWQD', 'QEQ'),
(4, 'raju12@gmail.com', 'QE', '878EW//', 'QWWQD', 'QEQ');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_three_day_three`
--

CREATE TABLE `assignment_three_day_three` (
  `s_no` int(100) NOT NULL,
  `login` varchar(500) NOT NULL,
  `situation` varchar(500) NOT NULL,
  `cause` varchar(500) NOT NULL,
  `elp_changed` varchar(500) NOT NULL,
  `outcomes` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_three_day_three`
--

INSERT INTO `assignment_three_day_three` (`s_no`, `login`, `situation`, `cause`, `elp_changed`, `outcomes`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4'),
(2, 'raju12@gmail.com', 'uhuh', 'ygyugyu', 'iojio', 'gug'),
(3, 'raju12@gmail.com', 'uhuh12', 'ygyugyu11', 'iojio112', 'gug12');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_three_day_two`
--

CREATE TABLE `assignment_three_day_two` (
  `s_no` int(100) NOT NULL,
  `login` varchar(100) NOT NULL,
  `situation` varchar(500) NOT NULL,
  `cause` varchar(500) NOT NULL,
  `elp_changed` varchar(500) NOT NULL,
  `outcomes` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_three_day_two`
--

INSERT INTO `assignment_three_day_two` (`s_no`, `login`, `situation`, `cause`, `elp_changed`, `outcomes`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4'),
(2, 'raju12@gmail.com', '1222342', '5646544', '7868768767', 'RERTERE'),
(3, 'raju12@gmail.com', '1222342', '5646544', '7868768767', 'GRGEG');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_two_day_five`
--

CREATE TABLE `assignment_two_day_five` (
  `s_no` int(50) NOT NULL,
  `login` varchar(100) NOT NULL,
  `positive_one` varchar(500) NOT NULL,
  `impact_one` varchar(500) NOT NULL,
  `positive_two` varchar(500) NOT NULL,
  `impact_two` varchar(500) NOT NULL,
  `positive_three` varchar(500) NOT NULL,
  `impact_three` varchar(500) NOT NULL,
  `positive_four` varchar(500) NOT NULL,
  `impact_four` varchar(500) NOT NULL,
  `positive_five` varchar(500) NOT NULL,
  `impact_five` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_two_day_five`
--

INSERT INTO `assignment_two_day_five` (`s_no`, `login`, `positive_one`, `impact_one`, `positive_two`, `impact_two`, `positive_three`, `impact_three`, `positive_four`, `impact_four`, `positive_five`, `impact_five`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'),
(2, 'raju12@gmail.com', 'coolHHu', 'UHUG', 'Uu', 'uhuhh', 'uhuh', 'uhu', 'huyuu', 'gygyuy', 'fyugyug', 'y'),
(3, 'raju12@gmail.com', 'coolHHu', 'UHUG', 'coolHHu', 'coolHHu', 'ewdwefwef', 'uhu', 'huyuu', 'gygyuy', 'fyugyug', 'y'),
(4, 'raju12@gmail.com', 'coolHHu', 'UHUG', 'coolHHu', 'coolHHu', 'ewdwefwef', 'uhu', 'huyuu', 'gygyuy', 'sxsxs', 'y');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_two_day_four`
--

CREATE TABLE `assignment_two_day_four` (
  `s_no` int(50) NOT NULL,
  `login` varchar(100) NOT NULL,
  `positive_one` varchar(500) NOT NULL,
  `impact_one` varchar(500) NOT NULL,
  `positive_two` varchar(500) NOT NULL,
  `impact_two` varchar(500) NOT NULL,
  `positive_three` varchar(500) NOT NULL,
  `impact_three` varchar(500) NOT NULL,
  `positive_four` varchar(500) NOT NULL,
  `impact_four` varchar(500) NOT NULL,
  `positive_five` varchar(500) NOT NULL,
  `impact_five` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_two_day_four`
--

INSERT INTO `assignment_two_day_four` (`s_no`, `login`, `positive_one`, `impact_one`, `positive_two`, `impact_two`, `positive_three`, `impact_three`, `positive_four`, `impact_four`, `positive_five`, `impact_five`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'),
(2, 'raju12@gmail.com', 'nnn', 'jjjj', 'kkk', 'hhh', 'jj', 'gg', 'ff', 'd', 'ss', 'dd'),
(3, 'raju12@gmail.com', 'nnn', 'jjjj', 'nnn', 'nnn', 'jj', 'gg', 'raju', 'd', 'ss', 'dd');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_two_day_one`
--

CREATE TABLE `assignment_two_day_one` (
  `s_no` int(50) NOT NULL,
  `login` varchar(100) NOT NULL,
  `positive_one` varchar(500) NOT NULL,
  `impact_one` varchar(500) NOT NULL,
  `positive_two` varchar(500) NOT NULL,
  `impact_two` varchar(500) NOT NULL,
  `positive_three` varchar(500) NOT NULL,
  `impact_three` varchar(500) NOT NULL,
  `positive_four` varchar(500) NOT NULL,
  `impact_four` varchar(500) NOT NULL,
  `positive_five` varchar(500) NOT NULL,
  `impact_five` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_two_day_one`
--

INSERT INTO `assignment_two_day_one` (`s_no`, `login`, `positive_one`, `impact_one`, `positive_two`, `impact_two`, `positive_three`, `impact_three`, `positive_four`, `impact_four`, `positive_five`, `impact_five`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'),
(2, 'raju12@gmail.com', 'qwe', 'qwee', 'e', 'yttyt', 'uyuy', 'ygyug', 'yyty', 'iui', 'yyutyu', 'iu8'),
(3, 'raju12@gmail.com', 'qwe', 'qwee', 'e', 'yttyt', 'uyuy', 'ygyug', 'yyty', 'iui', 'yyutyu', 'iu8'),
(4, 'raju12@gmail.com', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'),
(5, 'raju12@gmail.com', '1', '22', '33', '44', '55', '66', '77', '88', '99', '889'),
(6, 'raju12@gmail.com', '1', '22', '33', '44', '55', '66', '77', '88', '99', '889'),
(7, 'raju12@gmail.com', '1', '22', '33', '44', '55', '66', '77', '88', 'qww', '889'),
(8, 'rajujorhat46@gmail.com', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_two_day_seven`
--

CREATE TABLE `assignment_two_day_seven` (
  `s_no` int(50) NOT NULL,
  `login` varchar(100) NOT NULL,
  `positive_one` varchar(500) NOT NULL,
  `impact_one` varchar(500) NOT NULL,
  `positive_two` varchar(500) NOT NULL,
  `impact_two` varchar(500) NOT NULL,
  `positive_three` varchar(500) NOT NULL,
  `impact_three` varchar(500) NOT NULL,
  `positive_four` varchar(500) NOT NULL,
  `impact_four` varchar(500) NOT NULL,
  `positive_five` varchar(500) NOT NULL,
  `impact_five` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_two_day_seven`
--

INSERT INTO `assignment_two_day_seven` (`s_no`, `login`, `positive_one`, `impact_one`, `positive_two`, `impact_two`, `positive_three`, `impact_three`, `positive_four`, `impact_four`, `positive_five`, `impact_five`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'),
(2, 'raju12@gmail.com', '888', '999', '8788', '7676', '656', '567678', '654654', '7867', '6557', '87897'),
(3, 'raju12@gmail.com', '888', '999', '8788', '7676', '656', '567678', '654654', '7867', 'nnn6557', '87897');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_two_day_six`
--

CREATE TABLE `assignment_two_day_six` (
  `s_no` int(50) NOT NULL,
  `login` varchar(100) NOT NULL,
  `positive_one` varchar(500) NOT NULL,
  `impact_one` varchar(500) NOT NULL,
  `positive_two` varchar(500) NOT NULL,
  `impact_two` varchar(500) NOT NULL,
  `positive_three` varchar(500) NOT NULL,
  `impact_three` varchar(500) NOT NULL,
  `positive_four` varchar(500) NOT NULL,
  `impact_four` varchar(500) NOT NULL,
  `positive_five` varchar(500) NOT NULL,
  `impact_five` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_two_day_six`
--

INSERT INTO `assignment_two_day_six` (`s_no`, `login`, `positive_one`, `impact_one`, `positive_two`, `impact_two`, `positive_three`, `impact_three`, `positive_four`, `impact_four`, `positive_five`, `impact_five`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'),
(2, 'raju12@gmail.com', 'zzDRDRrdrdr', 'YGYG', 'YGYG', 'YGY', 'GYG', 'TF', 'YGY', 'FYU', 'GYFYUG', 'YUG'),
(3, 'raju12@gmail.com', 'zzDRDRrdrdr', 'YGYG', '1212', 'YGY', 'GYG', 'TF', 'YGY', 'FYU', 'GYFYUG', 'YUG');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_two_day_three`
--

CREATE TABLE `assignment_two_day_three` (
  `s_no` int(50) NOT NULL,
  `login` varchar(100) NOT NULL,
  `positive_one` varchar(500) NOT NULL,
  `impact_one` varchar(500) NOT NULL,
  `positive_two` varchar(500) NOT NULL,
  `impact_two` varchar(500) NOT NULL,
  `positive_three` varchar(500) NOT NULL,
  `impact_three` varchar(500) NOT NULL,
  `positive_four` varchar(500) NOT NULL,
  `impact_four` varchar(500) NOT NULL,
  `positive_five` varchar(500) NOT NULL,
  `impact_five` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_two_day_three`
--

INSERT INTO `assignment_two_day_three` (`s_no`, `login`, `positive_one`, `impact_one`, `positive_two`, `impact_two`, `positive_three`, `impact_three`, `positive_four`, `impact_four`, `positive_five`, `impact_five`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'),
(2, 'raju12@gmail.com', '22222', '33333', '444444', '555555', '666666', '7777777', '8888888', '999999', '766666', '34343'),
(3, 'raju12@gmail.com', '22222', '33333', '444444', '555555', '666666', '7777777', '8888888', '999999', 'rttttttt', '34343');

-- --------------------------------------------------------

--
-- Table structure for table `assignment_two_day_two`
--

CREATE TABLE `assignment_two_day_two` (
  `s_no` int(50) NOT NULL,
  `login` varchar(50) NOT NULL,
  `positive_one` varchar(500) NOT NULL,
  `impact_one` varchar(500) NOT NULL,
  `positive_two` varchar(500) NOT NULL,
  `impact_two` varchar(500) NOT NULL,
  `positive_three` varchar(500) NOT NULL,
  `impact_three` varchar(500) NOT NULL,
  `positive_four` varchar(500) NOT NULL,
  `impact_four` varchar(500) NOT NULL,
  `positive_five` varchar(500) NOT NULL,
  `impact_five` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment_two_day_two`
--

INSERT INTO `assignment_two_day_two` (`s_no`, `login`, `positive_one`, `impact_one`, `positive_two`, `impact_two`, `positive_three`, `impact_three`, `positive_four`, `impact_four`, `positive_five`, `impact_five`) VALUES
(1, 'raju12@gmail.com', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'),
(2, 'raju12@gmail.com', '22', '33', '44', '55', '66', '77', '88', '998', '88887', '7877'),
(3, 'raju12@gmail.com', '22', '33', '22', '22', '66', '77', '88', '998', '557', '7877'),
(4, 'raju12@gmail.com', '22222', '33333', '22222', '22222', '666666', '7777777', '8888888', '999999', '44446', '34343');

-- --------------------------------------------------------

--
-- Table structure for table `customersetpassword`
--

CREATE TABLE `customersetpassword` (
  `id` int(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customersetpassword`
--

INSERT INTO `customersetpassword` (`id`, `email`, `password`, `status`) VALUES
(1, '', '12345', '1'),
(2, 'rajujorhat46@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1'),
(3, 'raju12@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1'),
(4, 'rajujorhat46@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1'),
(5, '9886633980', '827ccb0eea8a706c4c34a16891f84e7b', '1'),
(6, 'raju12@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1'),
(7, 'rajujorhat46@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1'),
(8, 'rajujorhat46@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1'),
(9, 'rajujorhat46@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1'),
(10, 'rajujorhat46@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1'),
(11, 'test@gmail.com', '310dcbbf4cce62f762a2aaa148d556bd', '1'),
(12, 'rajujorhat64@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1');

-- --------------------------------------------------------

--
-- Table structure for table `customer_form`
--

CREATE TABLE `customer_form` (
  `s_no` int(100) NOT NULL,
  `login` varchar(300) NOT NULL,
  `email` varchar(500) NOT NULL,
  `age` int(255) NOT NULL,
  `marital` varchar(500) NOT NULL,
  `family_background` varchar(500) NOT NULL,
  `cities` varchar(500) NOT NULL,
  `achievement` varchar(500) NOT NULL,
  `profession` varchar(500) NOT NULL,
  `purpose` varchar(500) NOT NULL,
  `goal` varchar(500) NOT NULL,
  `awards` varchar(500) NOT NULL,
  `challenge` varchar(500) NOT NULL,
  `current_life` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_form`
--

INSERT INTO `customer_form` (`s_no`, `login`, `email`, `age`, `marital`, `family_background`, `cities`, `achievement`, `profession`, `purpose`, `goal`, `awards`, `challenge`, `current_life`) VALUES
(1, 'rohinimundra@rohinimundra.com', 'rajujorhat46@gmail.com', 0, 'uhuh', 'w', 'Bengaluru / Bangalore', 'uuhuh', 'uhuh', 'uhuh', 'hbhb', 'uhi', 'uu', 'uu'),
(2, 'rohinimundra@rohinimundra.com', 'rajujorhat46@gmail.com', 0, 'uhuh', 'w', 'Bengaluru / Bangalore', 'uuhuh', 'uhuh', 'uhuh', 'hbhb', 'uhi', 'uu', 'uu'),
(3, 'rohinimundra@rohinimundra.com', 'rajujorhat46@gmail.com', 12, 'uhuh', 'w', 'Bengaluru / Bangalore', 'uuhuh', 'uhuh', 'uhuh', 'hbhb', 'uhi', 'uu', 'uu');

-- --------------------------------------------------------

--
-- Table structure for table `customer_login`
--

CREATE TABLE `customer_login` (
  `id` int(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_login`
--

INSERT INTO `customer_login` (`id`, `email`, `password`, `created`, `modified`, `status`) VALUES
(1, 'rajujorhat46@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1');

-- --------------------------------------------------------

--
-- Table structure for table `customer_userlog`
--

CREATE TABLE `customer_userlog` (
  `id` int(20) NOT NULL,
  `userEmail` varchar(50) NOT NULL,
  `userip` binary(20) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logout` varchar(50) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_userlog`
--

INSERT INTO `customer_userlog` (`id`, `userEmail`, `userip`, `loginTime`, `logout`, `status`) VALUES
(1, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:35:00', '02-11-2017 02:05:00 PM', 1),
(2, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:35:09', '02-11-2017 02:05:09 PM', 1),
(3, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:35:15', '', 0),
(4, 'test@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:37:27', '', 0),
(5, 'test@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:37:36', '02-11-2017 02:07:36 PM', 1),
(6, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:54:33', '', 0),
(7, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:54:57', '02-11-2017 02:24:57 PM', 1),
(8, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:55:12', '02-11-2017 02:25:12 PM', 1),
(9, 'test@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:55:20', '02-11-2017 02:25:20 PM', 1),
(10, 'test@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:55:28', '', 0),
(11, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:58:12', '', 1),
(12, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:58:30', '', 0),
(13, 'test@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:58:50', '', 1),
(14, 'test@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:59:10', '', 0),
(15, 'test@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 08:59:19', '', 1),
(16, 'test@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 09:00:52', '', 0),
(17, 'test@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 09:01:03', '', 0),
(18, 'test@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 09:01:22', '', 1),
(19, 'test@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 09:01:42', '', 0),
(20, 'test@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 09:01:51', '02-11-2017 02:31:51 PM', 1),
(21, 'test@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-02 09:04:25', '', 1),
(22, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-20 07:35:14', '', 1),
(23, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-21 09:31:02', '', 1),
(24, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-21 10:02:44', '', 0),
(25, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-21 10:02:52', '', 1),
(26, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-21 11:19:37', '', 1),
(27, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-22 06:21:17', '', 1),
(28, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-22 06:41:51', '', 1),
(29, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-23 12:06:28', '', 1),
(30, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-24 10:14:35', '', 1),
(31, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-30 07:37:58', '', 0),
(32, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-30 07:38:05', '', 1),
(33, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-30 12:21:08', '', 0),
(34, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-11-30 12:21:15', '', 1),
(35, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-02 11:35:13', '', 0),
(36, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-02 11:35:20', '', 1),
(37, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-04 06:11:19', '', 1),
(38, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-04 12:16:05', '', 1),
(39, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-04 12:17:15', '', 1),
(40, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-05 05:22:31', '', 1),
(41, 'raju', 0x3a3a310000000000000000000000000000000000, '2017-12-18 10:35:30', '', 0),
(42, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-18 10:44:29', '', 0),
(43, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-18 10:44:40', '', 0),
(44, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-18 10:45:03', '', 1),
(45, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-20 11:52:03', '', 1),
(46, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-20 12:24:49', '', 1),
(47, 'rohinimundra@rohinimundra.com', 0x3a3a310000000000000000000000000000000000, '2017-12-21 05:18:23', '', 0),
(48, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-21 05:18:33', '', 1),
(49, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-21 12:34:41', '', 0),
(50, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-21 12:34:53', '', 0),
(51, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-21 12:34:59', '', 0),
(52, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-21 12:35:10', '', 0),
(53, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-21 12:35:30', '', 1),
(54, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-26 04:57:39', '', 1),
(55, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-26 05:19:38', '', 1),
(56, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-26 05:21:38', '', 1),
(57, 'raju12@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-26 05:43:48', '', 1),
(58, 'rajujorhat64@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-27 06:45:10', '', 1),
(59, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-28 07:25:45', '', 1),
(60, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-28 07:51:24', '28-12-2017 01:21:24 PM', 1),
(61, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-28 07:51:36', '', 1),
(62, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-28 09:19:13', '', 1),
(63, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-28 11:26:52', '', 1),
(64, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-29 09:00:01', '', 1),
(65, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-29 09:48:36', '', 1),
(66, 'rajujorhat46@gmail.com', 0x3a3a310000000000000000000000000000000000, '2017-12-29 11:10:03', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `s_no` int(20) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(50) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `age` int(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `alt_phone` varchar(20) NOT NULL,
  `profession` varchar(200) NOT NULL,
  `details_proof` varchar(200) NOT NULL,
  `joining_date` date NOT NULL,
  `end_date` date NOT NULL,
  `payment_inst` varchar(200) NOT NULL,
  `payment_first_inst` varchar(200) NOT NULL,
  `payment_second_inst` varchar(200) NOT NULL,
  `payment_third_inst` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE `form` (
  `id` int(10) NOT NULL,
  `name` varchar(32) NOT NULL,
  `phone` varchar(32) NOT NULL,
  `email` text NOT NULL,
  `signup_date` varchar(50) NOT NULL,
  `location` varchar(100) NOT NULL,
  `duration` varchar(50) NOT NULL,
  `payment_type` varchar(50) NOT NULL,
  `payment_one` varchar(50) NOT NULL,
  `payment_two` varchar(50) NOT NULL,
  `payment_three` varchar(50) NOT NULL,
  `hash` varchar(32) NOT NULL,
  `active` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`id`, `name`, `phone`, `email`, `signup_date`, `location`, `duration`, `payment_type`, `payment_one`, `payment_two`, `payment_three`, `hash`, `active`) VALUES
(1, 'Raju Mahanta', '9706336472', 'rajujorhat46@gmail.com', '2001-10-10', 'Bangalore', '3', '3', '1000', '200', '300', '3d2d8ccb37df977cb6d9da15b76c3f3a', 0),
(2, 'Kumar Mahanta', '9706336472', 'rajujorhat46@gmail.com', '2001-10-10', 'Bangalore', '3', '3', '1000', '200', '300', '9dfcd5e558dfa04aaf37f137a1d9d3e5', 0),
(3, 'Know know', '9706336472', 'rajujorhat46@gmail.com', '3001-10-10', 'Bangalore', '3', '3', '1000', '2000', 'kn', '92c8c96e4c37100777c7190b76d28233', 0),
(4, ' Miss Ankur Chowdhury', '9993379862', 'ankur240289@gmail.com', '2017-10-12', 'Bangalore', '3', '3', '1299', '322', '1222', '63538fe6ef330c13a05a3ed7e599d5f7', 0),
(5, 'Khushaali', '9774294940', 'khushaalik@gmail.com', '2017-10-16', 'Bangalore', '6', '6', 'asfasf', 'dff', 'fafa', '6364d3f0f495b6ab9dcf8d3b5c6e0b01', 0);

-- --------------------------------------------------------

--
-- Table structure for table `form_fillup`
--

CREATE TABLE `form_fillup` (
  `s_no` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `signup_date` date NOT NULL,
  `location` varchar(100) NOT NULL,
  `duration` varchar(20) NOT NULL,
  `payment_type` varchar(50) NOT NULL,
  `payment_one` varchar(50) NOT NULL,
  `payment_two` varchar(50) NOT NULL,
  `payment_three` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_fillup`
--

INSERT INTO `form_fillup` (`s_no`, `name`, `phone`, `email`, `signup_date`, `location`, `duration`, `payment_type`, `payment_one`, `payment_two`, `payment_three`) VALUES
(1, 'Raju Mahantas', '9706336472', 'rajujorhat46@gmail.com', '2001-10-10', 'Bangalore', '3', '3', '1000', '200', '300'),
(2, 'Testing Phase three', '1234567890', 'testigthree@gmail.com', '2001-12-12', 'Bangalore', '3 Years', 'Semi', '1200', '2000', '10000');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `s_no` int(50) NOT NULL,
  `login` varchar(100) NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `business` int(50) NOT NULL,
  `professional_life` int(50) NOT NULL,
  `self_value` int(50) NOT NULL,
  `relationships` int(50) NOT NULL,
  `total` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `quotes`
--

CREATE TABLE `quotes` (
  `id` int(20) NOT NULL,
  `quote` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quotes`
--

INSERT INTO `quotes` (`id`, `quote`, `author`) VALUES
(1, 'hrllo', 'raju'),
(2, 'efefef', 'raju');

-- --------------------------------------------------------

--
-- Table structure for table `quotes_meta`
--

CREATE TABLE `quotes_meta` (
  `s_no` int(11) NOT NULL,
  `number_reached` int(11) NOT NULL,
  `date_modified` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reference`
--

CREATE TABLE `reference` (
  `s_no` int(11) NOT NULL,
  `table_name` varchar(200) NOT NULL,
  `business` int(11) NOT NULL,
  `professional_life` int(11) NOT NULL,
  `self_value` int(11) NOT NULL,
  `relationships` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reference`
--

INSERT INTO `reference` (`s_no`, `table_name`, `business`, `professional_life`, `self_value`, `relationships`) VALUES
(1, 'assignmentone', 1, 0, 0, 1),
(2, 'assignmenttwo', 1, 0, 0, 0),
(3, 'assignmentthree', 1, 1, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `upload_ebook`
--

CREATE TABLE `upload_ebook` (
  `id` int(11) NOT NULL,
  `details` varchar(200) NOT NULL,
  `image_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload_ebook`
--

INSERT INTO `upload_ebook` (`id`, `details`, `image_name`) VALUES
(1, 'hello ', '6078.pdf'),
(2, 'video', 'VID_20160722_122527.mp4');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(20) NOT NULL,
  `userEmail` varchar(100) NOT NULL,
  `userip` binary(16) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `logout` varchar(100) NOT NULL,
  `status` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `userEmail`, `userip`, `loginTime`, `logout`, `status`) VALUES
(1, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-16 12:26:34', '16-10-2017 05:56:43 PM', 1),
(2, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-16 12:35:49', '', 1),
(3, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-16 12:36:00', '', 0),
(4, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-17 05:22:26', '', 1),
(5, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-17 05:22:49', '', 0),
(6, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:30:16', '', 0),
(7, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:30:37', '', 0),
(8, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:35:39', '', 0),
(9, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:35:59', '', 0),
(10, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:36:09', '', 0),
(11, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:36:51', '', 0),
(12, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:39:13', '', 0),
(13, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:39:56', '', 0),
(14, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:40:14', '', 0),
(15, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:44:53', '', 0),
(16, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:46:31', '', 0),
(17, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:46:57', '', 0),
(18, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:50:22', '', 0),
(19, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:50:38', '', 0),
(20, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:50:41', '', 0),
(21, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:50:47', '', 0),
(22, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:51:08', '', 0),
(23, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:51:57', '', 0),
(24, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:52:00', '', 0),
(25, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:52:46', '', 0),
(26, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 05:52:51', '', 0),
(27, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 06:15:52', '', 0),
(28, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-17 06:16:14', '17-10-2017 12:19:26 PM', 1),
(29, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 06:49:30', '', 0),
(30, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-17 06:53:29', '17-10-2017 12:23:32 PM', 1),
(31, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 07:07:39', '', 0),
(32, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-17 07:07:50', '17-10-2017 01:04:53 PM', 1),
(33, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 07:34:55', '', 0),
(34, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-17 07:35:30', '', 0),
(35, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-17 08:52:55', '', 1),
(36, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-18 04:26:37', '', 1),
(37, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-18 07:22:15', '', 1),
(38, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-24 10:32:48', '', 1),
(39, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-24 12:14:52', '24-10-2017 05:51:42 PM', 1),
(40, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-25 07:07:17', '', 1),
(41, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-25 09:19:14', '', 1),
(42, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-25 10:08:34', '', 1),
(43, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-25 10:08:58', '', 1),
(44, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-25 10:09:23', '', 0),
(45, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-25 10:10:27', '', 0),
(46, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-25 10:10:31', '', 0),
(47, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-25 10:11:05', '', 0),
(48, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-25 10:11:08', '', 0),
(49, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-25 10:11:47', '', 0),
(50, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-25 10:12:14', '', 0),
(51, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-25 10:13:49', '', 0),
(52, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-25 10:13:54', '', 0),
(53, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-25 10:14:10', '', 0),
(54, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-25 10:17:42', '', 0),
(55, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-25 10:17:52', '25-10-2017 03:50:28 PM', 1),
(56, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-25 10:20:31', '', 0),
(57, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-25 10:28:17', '', 0),
(58, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-30 05:50:16', '30-10-2017 11:20:28 AM', 1),
(59, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-30 06:22:22', '', 0),
(60, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-30 06:22:31', '', 1),
(61, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-30 08:24:27', '', 1),
(62, 'rohinimundra', 0x3a3a3100000000000000000000000000, '2017-10-30 09:51:10', '', 0),
(63, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-30 09:51:21', '30-10-2017 04:13:27 PM', 1),
(64, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-30 10:43:36', '30-10-2017 04:49:24 PM', 1),
(65, '9886633980', 0x3a3a3100000000000000000000000000, '2017-10-30 11:19:31', '', 0),
(66, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-30 11:20:06', '', 1),
(67, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-31 08:47:45', '', 0),
(68, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-31 08:47:52', '', 0),
(69, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-31 08:48:02', '31-10-2017 02:21:20 PM', 1),
(70, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-10-31 09:02:03', '', 1),
(71, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-11-02 07:31:37', '02-11-2017 01:01:39 PM', 1),
(72, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-11-02 08:35:56', '', 0),
(73, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-11-02 08:36:04', '', 0),
(74, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-11-02 08:36:20', '02-11-2017 02:06:34 PM', 1),
(75, 'rajujorhat46@gmail.com', 0x3a3a3100000000000000000000000000, '2017-11-21 09:49:17', '', 0),
(76, 'rajujorhat46@gmail.com', 0x3a3a3100000000000000000000000000, '2017-11-21 09:50:00', '', 0),
(77, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-11-21 09:50:17', '21-11-2017 03:32:23 PM', 1),
(78, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-11-23 09:01:40', '23-11-2017 03:10:55 PM', 1),
(79, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-11-23 11:19:47', '', 1),
(80, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-11-24 09:53:14', '', 1),
(81, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-11-30 07:27:17', '', 1),
(82, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-11-30 12:18:46', '30-11-2017 05:50:03 PM', 1),
(83, 'raju12@gmail.com', 0x3a3a3100000000000000000000000000, '2017-11-30 12:20:15', '', 0),
(84, 'rajujorhat46@gmail.com', 0x3a3a3100000000000000000000000000, '2017-11-30 12:20:46', '', 0),
(85, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-11-30 12:24:24', '', 1),
(86, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-01 07:35:20', '', 1),
(87, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-02 06:17:45', '', 1),
(88, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-20 09:48:56', '', 0),
(89, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-20 09:49:03', '', 1),
(90, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-20 10:42:32', '', 1),
(91, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-20 11:10:59', '', 0),
(92, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-20 11:11:07', '20-12-2017 05:21:03 PM', 1),
(93, 'raju12@gmail.com', 0x3a3a3100000000000000000000000000, '2017-12-20 11:51:13', '', 0),
(94, 'raju12@gmail.com', 0x3a3a3100000000000000000000000000, '2017-12-20 11:51:23', '', 0),
(95, 'raju12@gmail.com', 0x3a3a3100000000000000000000000000, '2017-12-20 11:51:32', '', 0),
(96, 'raju12@gmail.com', 0x3a3a3100000000000000000000000000, '2017-12-20 11:51:43', '', 0),
(97, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-20 12:19:13', '20-12-2017 05:54:34 PM', 1),
(98, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-21 05:08:45', '', 1),
(99, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-21 06:23:28', '', 1),
(100, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-21 12:32:56', '', 0),
(101, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-21 12:33:07', '', 1),
(102, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-21 12:38:23', '', 0),
(103, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-21 12:38:29', '', 1),
(104, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-22 06:48:04', '', 0),
(105, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-22 06:48:10', '', 1),
(106, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-26 05:16:45', '', 0),
(107, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-26 05:16:53', '26-12-2017 10:49:26 AM', 1),
(108, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-26 05:20:52', '', 0),
(109, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-26 05:20:57', '26-12-2017 10:51:13 AM', 1),
(110, 'raju12@gmail.com', 0x3a3a3100000000000000000000000000, '2017-12-26 05:21:21', '', 0),
(111, 'raju12@gmail.com', 0x3a3a3100000000000000000000000000, '2017-12-26 05:21:27', '', 0),
(112, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-26 05:24:41', '', 1),
(113, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-27 08:34:11', '', 0),
(114, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-27 08:34:20', '', 1),
(115, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-28 10:30:51', '', 1),
(116, 'rohinimundra@rohinimundra.com', 0x3a3a3100000000000000000000000000, '2017-12-28 11:30:58', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `forgot_pass_identity` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone`, `forgot_pass_identity`, `created`, `modified`, `status`) VALUES
(1, 'Rohini Mundra', 'rohinimundra@rohinimundra.com', '827ccb0eea8a706c4c34a16891f84e7b', '9886633980', 'd201ed88d90856b61331548ad9b2c561', '0000-00-00 00:00:00', '2017-10-11 11:56:42', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignmentone`
--
ALTER TABLE `assignmentone`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assignmenttwo`
--
ALTER TABLE `assignmenttwo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assignment_three_day_five`
--
ALTER TABLE `assignment_three_day_five`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `assignment_three_day_four`
--
ALTER TABLE `assignment_three_day_four`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `assignment_three_day_one`
--
ALTER TABLE `assignment_three_day_one`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `assignment_three_day_seven`
--
ALTER TABLE `assignment_three_day_seven`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `assignment_three_day_six`
--
ALTER TABLE `assignment_three_day_six`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `assignment_three_day_three`
--
ALTER TABLE `assignment_three_day_three`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `assignment_three_day_two`
--
ALTER TABLE `assignment_three_day_two`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `assignment_two_day_five`
--
ALTER TABLE `assignment_two_day_five`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `assignment_two_day_four`
--
ALTER TABLE `assignment_two_day_four`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `assignment_two_day_one`
--
ALTER TABLE `assignment_two_day_one`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `assignment_two_day_seven`
--
ALTER TABLE `assignment_two_day_seven`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `assignment_two_day_six`
--
ALTER TABLE `assignment_two_day_six`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `assignment_two_day_three`
--
ALTER TABLE `assignment_two_day_three`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `assignment_two_day_two`
--
ALTER TABLE `assignment_two_day_two`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `customersetpassword`
--
ALTER TABLE `customersetpassword`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_form`
--
ALTER TABLE `customer_form`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `customer_login`
--
ALTER TABLE `customer_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_userlog`
--
ALTER TABLE `customer_userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `details`
--
ALTER TABLE `details`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `form_fillup`
--
ALTER TABLE `form_fillup`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `quotes`
--
ALTER TABLE `quotes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotes_meta`
--
ALTER TABLE `quotes_meta`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `reference`
--
ALTER TABLE `reference`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `upload_ebook`
--
ALTER TABLE `upload_ebook`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignmentone`
--
ALTER TABLE `assignmentone`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `assignmenttwo`
--
ALTER TABLE `assignmenttwo`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `assignment_three_day_five`
--
ALTER TABLE `assignment_three_day_five`
  MODIFY `s_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `assignment_three_day_four`
--
ALTER TABLE `assignment_three_day_four`
  MODIFY `s_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `assignment_three_day_one`
--
ALTER TABLE `assignment_three_day_one`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `assignment_three_day_seven`
--
ALTER TABLE `assignment_three_day_seven`
  MODIFY `s_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `assignment_three_day_six`
--
ALTER TABLE `assignment_three_day_six`
  MODIFY `s_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `assignment_three_day_three`
--
ALTER TABLE `assignment_three_day_three`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `assignment_three_day_two`
--
ALTER TABLE `assignment_three_day_two`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `assignment_two_day_five`
--
ALTER TABLE `assignment_two_day_five`
  MODIFY `s_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `assignment_two_day_four`
--
ALTER TABLE `assignment_two_day_four`
  MODIFY `s_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `assignment_two_day_one`
--
ALTER TABLE `assignment_two_day_one`
  MODIFY `s_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `assignment_two_day_seven`
--
ALTER TABLE `assignment_two_day_seven`
  MODIFY `s_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `assignment_two_day_six`
--
ALTER TABLE `assignment_two_day_six`
  MODIFY `s_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `assignment_two_day_three`
--
ALTER TABLE `assignment_two_day_three`
  MODIFY `s_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `assignment_two_day_two`
--
ALTER TABLE `assignment_two_day_two`
  MODIFY `s_no` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `customersetpassword`
--
ALTER TABLE `customersetpassword`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `customer_form`
--
ALTER TABLE `customer_form`
  MODIFY `s_no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `customer_login`
--
ALTER TABLE `customer_login`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `customer_userlog`
--
ALTER TABLE `customer_userlog`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT for table `details`
--
ALTER TABLE `details`
  MODIFY `s_no` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `form`
--
ALTER TABLE `form`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `form_fillup`
--
ALTER TABLE `form_fillup`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `s_no` int(50) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `quotes`
--
ALTER TABLE `quotes`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `quotes_meta`
--
ALTER TABLE `quotes_meta`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `reference`
--
ALTER TABLE `reference`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `upload_ebook`
--
ALTER TABLE `upload_ebook`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
