<?php 
session_start();
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']){
	
	
}else{
	echo "You Are not an ADMIN. <a href='http://www.rohinimundra.com/admin/login.php'>Go to Login Page</a>";
	die();
}

?>

 <?php
			 include_once "connection.php";
			  
			$result=mysql_query("select * from assignmentone where completed = '1'");
			if($completed=='1')
			{
			$qry=mysql_query("insert into marks (login,table_name,business,professional_life,self_values,relationships,total) values('$user','assignmentone','1','0','0','1','10')")or die(mysql_error());
				}
			   $count=mysql_num_rows($qry);
			  ?>




</body>
</html>
