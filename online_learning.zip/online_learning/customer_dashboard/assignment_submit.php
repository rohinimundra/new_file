<?php session_start();
?>
<?php
include("connection.php");
extract($_POST);
$qry=mysql_query("update assignmentone SET s_no='$textfield',client='$client',state='$state',file_no='$file_no',county='$county',r_date='$r_date',product_type='$product_type',fee='$fee',copies='$copies',total='$total',paid='$paid',outstanding='$outstanding',notes='$notes' where s_no='$textfield'")or die(mysql_error());
if($qry)
{
 header('Location: assignment_one.php');

}
else
{
	print mysql_error();
}


?>