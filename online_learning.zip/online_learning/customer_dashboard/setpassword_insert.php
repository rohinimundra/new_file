<?php
include("connection.php");
extract($_POST);

$email=$_POST['email'];
$password=md5($_POST['password']);

$query=mysql_query("insert into customersetpassword(email,password) values('$email','$password')");

if($query)
{
	 header('Location: customer_login.php');
	 }
else
{
echo "<script>alert('Not register something went worng');</script>";
}

?>
