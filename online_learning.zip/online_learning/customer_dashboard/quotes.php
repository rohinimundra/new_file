<html>
<head>
<title>Quote of the day <?php echo date("F jS, Y"); ?></title>
</head>
<body>
<h1>Quote of the day <?php echo date("F jS, Y"); ?></h1>
<table border="2" cellpadding="6" style="border-collapse: collapse" bordercolor="#C0C0C0" width="60%" cellspacing="0">
  <tr>
    <td width="100%"><code>
    <?php
	
	
	// *****************************************************************************
	//  -------"The World's simplest PHP Message/Quote of the Day Script"----------
	// 
	// Author: Mads Søgaard (mads@acm.org)
	// Homepage: http://www.emacs.dk/quote/
	// Version: 1.0
	// 
	//
	// *****************************************************************************
	// -------------------- Description --------------------------------------------
	// 
	// "The World's simplest PHP Message/Quote of the Day Script" is a simple 
	// "quote-of-the-day script" that needs access to a MySQL database. It only 
	// consists of one script that's SIMPLE and hence easy to customize. This is how 
	// it works: You put any number of quotes/messages/whatever into the database, 
	// and then the script will show one quote every day. When all quotes have been 
	// shown, the script starts from the beginning of the quotes again. And if your 
	// quote-of-the-day page doesn't receive any visitors on a given day, the given 
	// quote-of-the-day will be shown the next day too. It simple, yet smart.
	//
	// 
	// *****************************************************************************
	// -------------------- Installation --------------------------------------------
	// 1. Upload the quote.php to your web server.
	// 2. Change the following variables $DB_SERVER,$DB_USER, $DB_PASS,	$DB_NAME 
	// (see below)
	// 3. Create the needed tables in your database with the quotes.sql file.
	// You can do it from the prompt (mysql -u[username] [-p] [database] < quotes.sql)
	// or you can use the wonderful phpMyAdmin at http://www.phpwizard.net/projects/phpMyAdmin/
	// 4. Point your browser to http://yourdomain/quotes.php
	// 5. Add your own quotes to the database and custumize the script as you see fit.
	// 
	// *****************************************************************************
	// -------------------- Do you find this script useful? ------------------------	
	//
	// Then by all means recommend it to other people! Or link back to me from your
	// homepage (that would be greatly appreciated) 
	// You can also review my script and give it good grades at:
	// http://www.hotscripts.com/PHP/Scripts_and_Programs/Quote_Display/
	// (or anywhere else you may have found it)
	// 
	// ******************************************************************************

	
	
	// ****************************************
	// Fill in your database information below
	// ****************************************
	$DB_SERVER = "localhost";
	$DB_USER = "root";
	$DB_PASS = ""; 
	$DB_NAME = "rohinimundra";	
	// ****************************************
	
	// ****************************************
	// you do NOT have to edit below this line 
	// ****************************************
	$con = mysql_connect($DB_SERVER, $DB_USER, $DB_PASS);
	mysql_select_db($DB_NAME);

	$getNoOfQuotesQuery = mysql_query("select count(*) from quotes", $con);
	$no_of_quotes = mysql_result($getNoOfQuotesQuery,0);
	
	$getMetaDataQuery = mysql_query("SELECT * FROM quotes_meta", $con);
	$row = mysql_fetch_row($getMetaDataQuery); 
	$number_reached = $row[1];
	$date_modified= $row[2];
	
	// get the current day of the month (from 1 to 31)
	$day_today = date("j");
	
	
	if ($date_modified != $day_today){
		// we have reached the end of the quotes
		if ($number_reached >($no_of_quotes - 1)){
			$number_reached = 1;
			$query3 = mysql_query('UPDATE quotes_meta SET date_modified = "'.$day_today.'", number_reached = "'.$number_reached.'"', $con);
			mysql_query($query3,$con);
		} else {
		// we haven't reached the end of the quotes
		// therefore we increment $number_reached
		$number_reached = $number_reached + 1;
		$query3 = mysql_query('UPDATE quotes_meta SET date_modified = "'.$day_today.'", number_reached = "'.$number_reached.'"', $con);
		mysql_query($query3,$con);
		}
	}
	
	// we get the quote with 'id = $number_reached' from the database
	$getQuoteQuery = mysql_query("SELECT quote,author FROM quotes WHERE id = ".$number_reached, $con);
	$row = mysql_fetch_row($getQuoteQuery);
	
	// we print the quote ($row[0]) and the author ($row[0])
	echo $row[0]."<p align='right'><i>-- " . $row[1];
	
	// close the database connection
	mysql_close($con);
?>
</i></code></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>