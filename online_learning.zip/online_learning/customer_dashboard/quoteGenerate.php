<?php

/****************************************************************************

   This is one of the files for the free "Quote of the Day" PHP 
   script from http://www.blazonry.com 

   All source code and an explanation of how it works and how 
   to set it up are at:
	http://www.blazonry.com/php/quoteoftheday.php

   This file runs on the server. Save the file as "generateQuote.php".
   
   Set up a cron job to run this file. It randomly selects a quote and 
   saves it to a text file.
   
*****************************************************************************/


	$file = "todaysQuote.txt";
	// read the file into an array
	$quoteArray = file("quotes.txt");

	// set random seed
	//srand($seed);

	//get the random number
	$qrnd = rand(0,sizeof($quoteArray)-1);

	// pick quote name from random numbers
	$quote = "$quoteArray[$qrnd]";


	//write the string to the file

	// Note: mode 'w' opens for writing only; place the file pointer at 
	//   the beginning of the file and truncate the file to zero length.
	//   If the file does not exist, attempt to create it.
	
	$fh = fopen($file, "w");
	fputs($fh, $quote);
	fclose($fh);

	//uncomment the following line for debugging and testing
	//echo ("wrote \"$quote\" <br />to the file $file");

?>
