<?php session_start();
?>
<?php
include("connection.php");
extract($_POST);
$username=$_SESSION['login'];

$qry=mysql_query("insert into assignment_two_day_one (login, positive_one, impact_one, positive_two, impact_two, positive_three, impact_three, positive_four, impact_four, positive_five, impact_five) values('$username','$positive_one', '$impact_one', '$positive_two', '$impact_two', '$positive_three', '$impact_three', '$positive_four', '$impact_four', '$positive_five', '$impact_five')")or die(mysql_error());
if($qry)
{
 header('Location: assignment_two_day_one_view.php? id='. $row['id'] . '');
}
else
{
	print mysql_error();
}


?>
