<?php
include("connection.php");
extract($_POST);
$qry=mysql_query("update assignmentone SET id='$textfield',activities_one='$activities_one',relationships_one='$relationships_one', identity_one='$identity_one',activities_two='$activities_two',relationships_two='$relationships_two',identity_two='$identity_two',activities_three='$activities_three',relationships_three='$relationships_three',identity_three='$identity_three',activities_four='$activities_four',relationships_four='$relationships_four',identity_four='$identity_four',activities_five='$activities_five',relationships_five='$relationships_five',identity_five='$identity_five',activities_six='$activities_six',relationships_six='$relationships_six',identity_six='$identity_six',certainty_one='$certainty_one',certainty_two='$certainty_two',variety_one='$variety_one',variety_two='$variety_two',significance_one='$significance_one',significance_two='$significance_two',connection_one='$connection_one',connection_two='$connection_two',growth_one='$growth_one',growth_two='$growth_two',contribution_one='$contribution_one',contribution_two='$contribution_two',completed='1' where id='$textfield'")or die(mysql_error());
if($qry)
{
  header('Location: assignmentone_file.php');
}
else
{
	print mysql_error();
}
?>
