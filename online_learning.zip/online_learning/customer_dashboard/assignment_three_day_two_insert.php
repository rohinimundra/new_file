<?php session_start();
?>
<?php
include("connection.php");
extract($_POST);
$username=$_SESSION['login'];

$qry=mysql_query("insert into assignment_three_day_two (login, situation, cause, elp_changed, outcomes) values('$username','$situation', '$cause', '$elp_changed', '$outcomes')")or die(mysql_error());
if($qry)
{
 header('Location: assignment_three_day_two_view.php? id='. $row['id'] . '');
}
else
{
	print mysql_error();
}


?>
