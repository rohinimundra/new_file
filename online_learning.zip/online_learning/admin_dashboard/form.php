<?php 
session_start();
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']){
	
	
}else{
	echo "You Are not an ADMIN. <a href='http://www.rohinimundra.com/admin/login.php'>Go to Login Page</a>";
	die();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />

<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<script>
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>
</head>
<body>

<!--Header-part-->
<div id="header"></div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <?php if(strlen($_SESSION['login']))
    {   ?> 
  <span class="text">Welcome <?php echo htmlentities($_SESSION['username']);?></span><b class="caret"> </b></a>
     
       <?php } ?>
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="admin_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
  
    
    <li class=""><a title="" href="admin_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
  <input type="text" placeholder="Search here..."/>
  <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="index.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
    <li><a href="#"><i class="icon icon-th"></i> <span>Tables</span></a></li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Forms</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="form.php">Customer Form</a></li>
        <li><a href="file_search.php">File View</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Assignment One</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="assignmentone_file.php">Assignment One</a></li>
        </ul>
    </li>
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Assignment Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="assignment_two_day_one.php">Day One</a></li>
        <li><a href="assignment_two_day_two.php">Day Two</a></li>
        <li><a href="assignment_two_day_three.php">Day Three</a></li>
         <li><a href="assignment_two_day_four.php">Day Four</a></li>
          <li><a href="assignment_two_day_five.php">Day Five</a></li>
           <li><a href="assignment_two_day_six.php">Day Six</a></li>
            <li><a href="assignment_two_day_seven.php">Day Seven</a></li>
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Assignment Three</span> <span class="label label-important"></span></a>
      <ul>
        
         <li><a href="assignment_three_day_one.php">Day One</a></li>
         <li><a href="assignment_three_day_two.php">Day Two</a></li>
         <li><a href="assignment_three_day_three.php">Day Three</a></li>
         <li><a href="assignment_three_day_four.php">Day Four</a></li>
         <li><a href="assignment_three_day_five.php">Day Five</a></li>
         <li><a href="assignment_three_day_six.php">Day Six</a></li>
         <li><a href="assignment_three_day_seven.php">Day Seven</a></li>
       
       
      </ul>
    </li>
   

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  <h1>Fill-up the form correctly</h1>
</div>
<div class="container-fluid">
  <hr>
  <div class="row-fluid">
  
<form class="form-horizontal" role="form"  method="post" action="companyreg_insert.php" onSubmit="return check();">

    <div class="span6">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
         
        </div> 
        
        <div class="widget-content nopadding">
         
            <div class="control-group">
              <label class="control-label">Name : <span class="require">*</span></label>
              <div class="controls">
                
                  <input type="text" class="span11" id="name" name="name" placeholder="Name" required>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Phone : <span class="require">*</span></label>
              <div class="controls">
               <input type="text" class="span11" id="phone" name="phone" required placeholder="Phone" onkeypress='validate(event)'>
                
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Email : <span class="require">*</span></label>
              <div class="controls">
                
                 <input type="email" class="span11" id="email" name="email" placeholder="Enter Email Id" required>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Sign Up Date : <span class="require">*</span></label>
              <div class="controls">
               
                <input type="date" class="span11" id="signup_date" name="signup_date" value="<?php echo date("Y-m-d") ?>" required>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Location : <span class="require">*</span></label>
              <div class="controls">
               
                 <input type="text" class="span11" id="location" name="location" placeholder="Location" required>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Duration : <span class="require">*</span></label>
              <div class="controls">
                <input type="text" class="span11" id="duration" name="duration" placeholder="Duration" required>
              </div>
            </div>
             <div class="control-group">
              <label class="control-label">Payment Type : <span class="require">*</span></label>
              <div class="controls">
               <select class="span11" name="payment_type" id="payment_type">
           <option></option>
          <option value="Single">Single</option>
          <option value="Multiple">Multiple</option>
           </select>
              </div>
            </div>
             </div></div></div>
     
     <div class="span6">
     <div class="widget-box">
     <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          
        </div>
        <div class="widget-content nopadding">

        <div class="control-group">
              <label class="control-label"> Payment Part One : <span class="require">*</span></label>
              <div class="controls">
                
                 <input type="text" class="span11" id="payment_one" name="payment_one" value="0" required onkeypress='validate(event)'>
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">First Payment Date : <span class="require">*</span></label>
              <div class="controls">
               <input type="date" class="span11" id="payment_one_date" name="payment_one_date" value="<?php echo date("Y-m-d") ?>" required>
               
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Payment Part Two :</label>
              <div class="controls">
                 <input type="text" class="span11" id="payment_two" name="payment_two" onkeypress='validate(event)' value="0">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Second Payment Date :</label>
              <div class="controls">
                 <input type="date" class="span11" id="payment_two_date" name="payment_two_date" value="<?php echo date("Y-m-d") ?>">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Payment Part Three :</label>
              <div class="controls">
                <input type="text" class="span11" id="payment_three" name="payment_three" onkeypress='validate(event)' value="0">
              </div>
            </div>
            <div class="control-group">
              <label class="control-label">Third Payment Date :</label>
              <div class="controls">
                 <input type="date" class="span11" id="payment_third_date" name="payment_third_date"  value="<?php echo date("Y-m-d") ?>">
              </div>
            </div>
           
         
           
         
          
        </div>
      </div>
     
              <button type="submit" class="btn btn-success">Save</button>
           
      </form>
  
           
   
      
        </div>
      </div>
    </div>
  </div>
 
</div></div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>
</body>
</html>
