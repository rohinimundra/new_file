<?php
session_start();
include('includes/config.php');
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="css/colorpicker.css" />
<link rel="stylesheet" href="css/datepicker.css" />
<link rel="stylesheet" href="css/uniform.css" />
<link rel="stylesheet" href="css/select2.css" />
<link rel="stylesheet" href="css/matrix-style.css" />
<link rel="stylesheet" href="css/matrix-media.css" />
<link rel="stylesheet" href="css/bootstrap-wysihtml5.css" />
<link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="datatable/jquery.dataTables.min.css">
<script>
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
</script>
</head>
<style>

th a.sort-by { 
	padding-right: 15px;
	position: relative;
}
a.sort-by:before,
a.sort-by:after {
	border: 4px solid transparent;
	content: "";
	display: block;
	height: 0;
	right: 5px;
	top: 50%;
	position: absolute;
	width: 0;
}
a.sort-by:before {
	border-bottom-color: #666;
	margin-top: -9px;
}
a.sort-by:after {
	border-top-color: #666;
	margin-top: 1px;
}
</style>
<body>

<!--Header-part-->
<div id="header"></div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li  class="dropdown" id="profile-messages" ><a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i class="icon icon-user"></i>  <?php if(strlen($_SESSION['login']))
    {   ?> 
  <span class="text">Welcome <?php echo htmlentities($_SESSION['username']);?></span><b class="caret"> </b></a>
     
       <?php } ?>
      <ul class="dropdown-menu">
        <li><a href="#"><i class="icon-user"></i> My Profile</a></li>
        <li class="divider"></li>
        <li><a href="#"><i class="icon-check"></i> My Tasks</a></li>
        <li class="divider"></li>
        <li><a href="admin_logout.php"><i class="icon-key"></i> Log Out</a></li>
      </ul>
    </li>
  
    
    <li class=""><a title="" href="admin_logout.php"><i class="icon icon-share-alt"></i> <span class="text">Logout</span></a></li>
  </ul>
</div>

<!--start-top-serch-->
<div id="search">
  <input type="text" placeholder="Search here..."/>
  <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
</div>
<!--close-top-serch--> 

<!--sidebar-menu-->

<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="active"><a href="index.php"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
    <li><a href="#"><i class="icon icon-th"></i> <span>Tables</span></a></li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Forms</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="form.php">Customer Form</a></li>
        <li><a href="file_search.php">File View</a></li>
       
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Assignment One</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="assignmentone_file.php">Assignment One</a></li>
        </ul>
    </li>
   <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Assignment Two</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="assignment_two_day_one.php">Day One</a></li>
        <li><a href="assignment_two_day_two.php">Day Two</a></li>
        <li><a href="assignment_two_day_three.php">Day Three</a></li>
         <li><a href="assignment_two_day_four.php">Day Four</a></li>
          <li><a href="assignment_two_day_five.php">Day Five</a></li>
           <li><a href="assignment_two_day_six.php">Day Six</a></li>
            <li><a href="assignment_two_day_seven.php">Day Seven</a></li>
      </ul>
    </li>
    <li class="submenu"> <a href=""><i class="icon icon-th-list"></i> <span>Assignment Three</span> <span class="label label-important"></span></a>
      <ul>
         <li><a href="assignment_three_day_one.php">Day One</a></li>
        <li><a href="assignment_three_day_two.php">Day Two</a></li>
        <li><a href="assignment_three_day_three.php">Day Three</a></li>
         <li><a href="assignment_three_day_four.php">Day Four</a></li>
          <li><a href="assignment_three_day_five.php">Day Five</a></li>
           <li><a href="assignment_three_day_six.php">Day Six</a></li>
            <li><a href="assignment_three_day_seven.php">Day Seven</a></li>
       
       
      </ul>
    </li>
   

 
</div>
<!--close-left-menu-stats-sidebar-->

<div id="content" style="padding-bottom:200px; padding-left:20px;">
<div id="content-header">
  <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  <h1>Assignment Three file</h1>
</div>
<div class="container-fluid">
  <hr>
  <div class="row-fluid">
  
    <div class="span12">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
        
        <form class="form-horizontal" role="form" method="post">
<table border="1" class="table table-bordered data-table" id="order_details" style="margin-left:20px; margin-top:30px;">
<thead>

<tr>
<th> <a href="#" class="">S.No.</a></th>
<th scope="col"><a href="#" class="">Situation</a></th>
<th scope="col"><a href="#" class="">Cause</a></th>
<th scope="col"><a href="#" class="">Elp Changed</a></th>
<th scope="col"><a href="#" class="">Outcomes</a></th>
<th scope="col"><a href="#" class="">User</a></th>
<th scope="col"><a href="#" class="sort-by">Action</a></th>
</tr>
</thead>
<tbody>
 <?php
			  include_once "connection.php";
			  
			$result=mysql_query("select * from assignment_three_day_three");
			   $count=mysql_num_rows($result);
			  
			  if( $count>0)
			  {
				  while($row=mysql_fetch_array($result))
				  {
			  
			  ?>
<tr>
<td align="center"><?php echo $row["s_no"];  ?></td>
<td><?php echo $row["situation"];  ?></td>
<td><?php echo $row["cause"];  ?></td>
<td><?php echo $row["elp_changed"];  ?></td>
<td><?php echo $row["outcomes"];  ?></td>
<td><?php echo $row["login"];  ?></td>
<?php 
echo' <td align="center"><a href="assignment_three_day_three_view.php? s_no='. $row['s_no'] . '">  <button type="button" >View</button> </a>';
		
		 ?>

         </td>
                <?php
				  }
			  }
	      
		  ?>

</tr>


</tbody>
</table>
</form>
        
         
        </div> 
        
       </div></div>
     
    
      </div>
    </div>
  </div>
 
</div></div>
<!--Footer-part-->
<div class="row-fluid">
  <div id="footer" class="span12"> 2017 &copy; Brought to you by <a href="http://www.7intelligence.com/">7Intelligence</a> </div>
</div>
<!--end-Footer-part--> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/bootstrap-colorpicker.js"></script> 
<script src="js/bootstrap-datepicker.js"></script> 
<script src="js/jquery.toggle.buttons.js"></script> 
<script src="js/masked.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.form_common.js"></script> 
<script src="js/wysihtml5-0.3.0.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/bootstrap-wysihtml5.js"></script> 
<script>
	$('.textarea_editor').wysihtml5();
</script>

 <script type="text/javascript" src="datatable/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="datatable/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="datatable/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
       $('#order_details').DataTable({
            "lengthMenu": [[10,50, 100, 500, -1], [10,50, 100, 500, "All"]],
            "iDisplayLength": 10
        });
    </script>
                <script> 
function confirmationDelete(anchor)
{
   var conf = confirm('Are you sure want to delete this record?');
   if(conf)
      window.location=anchor.attr("href");
}
</script>   
</body>
</html>
